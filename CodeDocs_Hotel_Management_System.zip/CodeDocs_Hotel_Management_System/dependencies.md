# Dependency Documentation

## Backend Dependencies

| Dependency | Version / Source | Purpose |
|---|---|---|
| `spring-boot-starter-parent` | 3.3.5 | Spring Boot dependency management. |
| `spring-boot-starter-web` | Managed | REST APIs and embedded Tomcat. |
| `spring-boot-starter-jdbc` | Managed | JdbcTemplate database access. |
| `mysql-connector-j` | Runtime | MySQL driver. |
| `openpdf` | 1.3.39 | PDF receipt generation. |
| `spring-boot-starter-test` | Test | Backend test support. |

Backend runtime:

- Java 21
- Maven
- MySQL

## Frontend Dependencies

| Dependency | Version | Purpose |
|---|---|---|
| `@angular/core` | ^19.2.0 | Angular framework. |
| `@angular/forms` | ^19.2.0 | Reactive forms. |
| `@angular/router` | ^19.2.0 | Routing. |
| `rxjs` | ~7.8.0 | Reactive utilities. |
| `zone.js` | ~0.15.0 | Angular change detection integration. |
| `jspdf` | ^4.2.1 | Frontend PDF capability. |
| `typescript` | ~5.7.2 | TypeScript compiler. |
| `@angular/cli` | ^19.2.25 | Angular tooling. |

## Commands

Frontend:

```bash
npm install
npm start
npm run build
```

Backend:

```bash
mvn spring-boot:run
mvn -DskipTests package
```

Database:

```bash
mysql -u root -p < database/01_create_schema.sql
mysql -u root -p < database/02_seed_demo_data.sql
mysql -u root -p < database/03_production_feature_updates.sql
```

Environment variables:

| Variable | Purpose |
|---|---|
| `DB_URL` | MySQL JDBC URL. |
| `DB_USERNAME` | Database username. |
| `DB_PASSWORD` | Database password. |
