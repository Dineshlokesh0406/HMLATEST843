# API Contract Details

Base URL:

```text
http://localhost:8080/api
```

All JSON endpoints use `Content-Type: application/json` unless downloading PDFs.

## Authentication API

### Register Customer

`POST /auth/register`

Request:

```json
{
  "fullName": "Aarav Sharma",
  "email": "aarav@example.com",
  "countryCode": "+91",
  "phoneNumber": "9876543210",
  "address": "221 Residency Road, Bengaluru",
  "username": "aarav",
  "password": "Cust@123",
  "confirmPassword": "Cust@123"
}
```

Response:

```json
{
  "message": "Registration successful.",
  "userCode": "CUS1002",
  "fullName": "Aarav Sharma",
  "email": "aarav@example.com",
  "role": "CUSTOMER"
}
```

### Login

`POST /auth/login`

```json
{
  "role": "CUSTOMER",
  "usernameOrEmail": "aarav",
  "password": "Cust@123"
}
```

Errors include:
- `Invalid username or password.`
- `Selected role does not match the user account.`
- `Your account is locked. Please contact support.`

### Forgot Password Identity Verification

`POST /auth/forgot-password`

```json
{
  "username": "aarav",
  "email": "aarav@example.com",
  "phoneNumber": "9876543210"
}
```

Response:

```json
{
  "message": "Details verified. You can reset your password now.",
  "resetToken": "uuid-token-value",
  "tokenExpiresAt": "2026-05-14T01:04:36"
}
```

### Reset Password

`POST /auth/reset-password`

```json
{
  "token": "uuid-token-value",
  "newPassword": "NewPass@123",
  "confirmPassword": "NewPass@123"
}
```

## Customer API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/customer/profile/{userCode}` | Get profile details. |
| PUT | `/customer/profile/{userCode}` | Update profile details. |
| GET | `/customer/cities` | List city options. |
| GET | `/customer/hotels/{cityCode}` | List hotels in a city. |
| GET | `/customer/rooms/availability` | Browse available rooms by optional dates. |
| POST | `/customer/rooms/search` | Search room availability. |
| GET | `/customer/bookings/{customerCode}` | List customer bookings. |
| POST | `/customer/bookings` | Create booking. |
| PUT | `/customer/bookings/{bookingCode}` | Update booking. |
| POST | `/customer/bookings/{bookingCode}/cancel` | Cancel booking. |
| GET | `/customer/bookings/{bookingCode}/receipt` | Download PDF receipt. |
| GET | `/customer/complaints/{customerCode}` | List customer complaints. |
| POST | `/customer/complaints` | Create complaint. |
| PATCH | `/customer/complaints/{complaintCode}` | Update complaint status. |

### Room Search Request

```json
{
  "cityCode": "BLR",
  "hotelCode": "BLR05",
  "checkInDate": "2026-05-15",
  "checkOutDate": "2026-05-16",
  "adults": 2,
  "children": 0,
  "roomType": "Deluxe"
}
```

### Booking Create Request

```json
{
  "customerCode": "CUS1001",
  "roomNumber": "BLR05-101",
  "checkInDate": "2026-05-15",
  "checkOutDate": "2026-05-16",
  "adults": 2,
  "children": 0,
  "paymentMethod": "Card",
  "specialRequests": "Late check-in"
}
```

### Complaint Create Request

```json
{
  "customerCode": "CUS1001",
  "bookingCode": "BKG3001",
  "category": "SERVICE ISSUE",
  "complaintTitle": "Room service delay",
  "complaintDescription": "Room service was delayed and needs follow-up.",
  "contactPreference": "Email"
}
```

## Admin API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/admin/dashboard` | Dashboard counts. |
| GET | `/admin/rooms` | List rooms. |
| POST | `/admin/rooms` | Add/update room. |
| GET | `/admin/reservations` | List all reservations. |
| GET | `/admin/reservations/page` | Paginated reservations with filters. |
| POST | `/admin/reservations` | Create reservation. |
| GET | `/admin/users` | List users. |
| GET | `/admin/users/page` | Paginated users. |
| PATCH | `/admin/users/{userCode}/status` | Update account status. |
| GET | `/admin/bills` | List bills. |
| POST | `/admin/bills` | Create bill. |
| GET | `/admin/complaints` | List complaints. |
| PATCH | `/admin/complaints/{complaintCode}` | Assign/update complaint. |
| GET | `/admin/reservations/{bookingCode}/receipt` | Download receipt. |

### Paginated Reservation Query

`GET /admin/reservations/page?page=0&size=10&sort=bookedAt&direction=desc&search=aarav&status=CONFIRMED&paymentStatus=PAID&date=2026-05-15`

Response wrapper:

```json
{
  "content": [],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 0,
  "totalPages": 1
}
```

## Staff API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/staff/complaints` | List staff complaint workspace records. |
| PATCH | `/staff/complaints/{complaintCode}` | Update complaint status and notes. |
