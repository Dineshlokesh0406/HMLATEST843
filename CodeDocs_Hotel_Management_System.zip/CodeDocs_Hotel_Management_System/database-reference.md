# Database Reference

Schema scripts live in the `database` folder.

- `01_create_schema.sql` - base schema.
- `02_seed_demo_data.sql` - demo data.
- `03_production_feature_updates.sql` - production feature updates.

## Main Tables

### `users`

Stores customer, admin and staff accounts.

Important fields:

- `user_id`, `user_code`
- `full_name`, `email`, `country_code`, `phone_number`, `address_line`
- `username`, `password_hash`
- `role`, `account_status`, `failed_login_attempts`

### `cities` / `hotels`

Catalog tables for city and hotel selection.

### `rooms`

Stores room number, room type, bed type, price, status, bookable flag, occupancy limits, size and description.

### `bookings`

Stores reservations including customer, room, dates, guests, status, payment status, total amount and cancellation date.

### `bills`

Stores room charges, service charges, taxes, discounts, total amount, payment status and issue date.

### `complaints`

Stores customer complaints, categories, status, assigned staff, response text, resolution notes and audit timestamps.

Complaint statuses:

- Pending
- Assigned
- In Progress
- Resolved
- Closed

### `password_reset_tokens`

Stores reset token hashes, expiration and used timestamps for password reset flow.
