# Hotel Management System - Code Documentation

## Purpose
Technical documentation for developers working on the Hotel Management System.

The project is built with:
- Frontend: Angular 19
- Backend: Spring Boot 3.3.5, Java 21
- Database: MySQL
- Data access: Spring JDBC / JdbcTemplate
- PDF generation: OpenPDF on backend

## Contents

| File | Description |
|---|---|
| `architecture-overview.md` | End-to-end architecture and request flow. |
| `api-contracts.md` | API contracts with request/response examples. |
| `openapi.yaml` | Swagger/OpenAPI-style endpoint contract. |
| `backend-reference.md` | Backend package, class and method documentation. |
| `frontend-reference.md` | Angular component/service/validator documentation. |
| `database-reference.md` | Schema and table purpose overview. |
| `dependencies.md` | Frontend and backend dependency details. |
| `index.html` | Offline HTML index for browsing the docs. |
