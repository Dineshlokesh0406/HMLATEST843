# Architecture Overview

## High-Level Architecture

```text
Browser / Angular UI
        |
        | HTTP JSON / PDF download
        v
Spring Boot REST Controllers
        |
        v
Service Layer - business rules and validation orchestration
        |
        v
Repository Layer - JdbcTemplate SQL queries
        |
        v
MySQL Database
```

## Frontend Responsibilities

- Route-based navigation for landing, login, register, customer, admin and staff pages.
- Reactive forms for registration, login, forgot password, booking, payment, complaints and profiles.
- Immediate frontend validation before API calls.
- Customer booking flow with room selection, guest validation, payment timer and receipt download.
- Admin dashboards for rooms, reservations, users, bills and complaints.
- Staff complaint workspace with status updates and remarks.
- Modal/popup interactions that block background interaction.

## Backend Responsibilities

- REST API routing through controller classes.
- Secondary validation and business rule enforcement.
- Password hashing and failed-login lockout.
- Password reset using username + email + phone verification.
- Booking creation, update and cancellation.
- Admin reservation/user pagination queries.
- Complaint creation, assignment and status updates.
- PDF receipt generation.
- MySQL persistence through repository classes.

## Main Runtime Flows

### Login Flow
1. Angular `LoginComponent` validates role, username and password.
2. `MockHotelService.login()` calls `POST /api/auth/login`.
3. `AuthController` delegates to `AuthService.login()`.
4. `AuthService` verifies role, account status and password hash.
5. Angular stores session user and loads role-specific data.

### Forgot Password Flow
1. User enters username, registered email and registered phone number.
2. Angular validates required fields and email/phone format.
3. `POST /api/auth/forgot-password` verifies all three details.
4. Backend creates a short-lived reset token stored as a hash.
5. Angular shows reset password fields.
6. `POST /api/auth/reset-password` updates the password after token validation.

### Booking Flow
1. Customer searches rooms or selects a landing page room card.
2. Angular carries selected room details into booking confirmation.
3. Confirmation validates dates and guest count.
4. Guest count above 12 shows a blocking error popup.
5. Payment validates card fields and starts a 5-minute timer.
6. Backend creates booking and billing information.
7. Customer can download a PDF receipt.

### Complaint Flow
1. Customer submits complaint for an eligible owned booking.
2. Backend enforces ownership and complaint time-window rules.
3. Admin views all complaints and assigns staff.
4. Staff updates complaint status and resolution notes.
5. Audit timestamps track created, assigned and resolved states.

## Security Notes

- Passwords are hashed with SHA-256 before storage.
- Password reset tokens are stored as hashes.
- Backend validation remains a secondary security layer.
- Failed login attempts can lock an account.

## Implementation Note

The frontend service is named `MockHotelService`, but it now acts as the Angular API client and shared state service.
