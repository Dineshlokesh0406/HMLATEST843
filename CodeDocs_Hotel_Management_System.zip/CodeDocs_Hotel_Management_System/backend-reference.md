# Backend Reference

## Package Overview

| Package | Purpose |
|---|---|
| `com.hm.backend.config` | CORS and JDBC configuration. |
| `com.hm.backend.controller` | REST endpoint classes. |
| `com.hm.backend.dto` | Java record request/response DTOs. |
| `com.hm.backend.exception` | API exception and global handler. |
| `com.hm.backend.repository` | JdbcTemplate SQL data access. |
| `com.hm.backend.service` | Business logic and orchestration. |
| `com.hm.backend.util` | Hashing and validation helpers. |

## Controllers

### `AuthController`

Base route: `/api/auth`

- `register(RegisterRequest)` - registers a customer.
- `login(LoginRequest)` - authenticates user by role and credentials.
- `forgotPassword(ForgotPasswordRequest)` - verifies username/email/phone and returns reset token.
- `resetPassword(ResetPasswordRequest)` - updates password after token validation.

### `CustomerController`

Base route: `/api/customer`

- `profile(userCode)` - returns profile details.
- `updateProfile(userCode, request)` - updates profile.
- `cities()` / `hotels(cityCode)` - catalog lookups.
- `browseRooms(...)` / `searchRooms(request)` - room availability.
- `bookings(customerCode)` - customer booking history.
- `createBooking(request)` - booking creation.
- `updateBooking(bookingCode, request)` - booking modification.
- `cancelBooking(bookingCode)` - booking cancellation.
- `bookingReceipt(bookingCode)` - PDF receipt download.
- `complaints(customerCode)` - customer complaints.
- `createComplaint(request)` - complaint creation.
- `updateComplaint(complaintCode, request)` - complaint status update.

### `AdminController`

Base route: `/api/admin`

- `dashboard()` - dashboard counters.
- `rooms()` / `saveRoom(request)` - room listing and save.
- `reservationPage(...)` - paginated reservations with filters.
- `userPage(...)` - paginated user listing.
- `updateUserStatus(userCode, request)` - account status update.
- `bills()` / `createBill(request)` - bill listing and creation.
- `complaints()` / `updateComplaint(...)` - complaint assignment and status workflow.
- `bookingReceipt(bookingCode)` - admin PDF receipt download.

### `StaffController`

Base route: `/api/staff`

- `complaints()` - staff complaint workspace records.
- `updateComplaint(complaintCode, request)` - status and notes update.

## Services

### `AuthService`

Handles registration, login, failed attempt tracking, identity-based password reset and password updates.

### `CustomerService`

Handles profile, room search, booking create/update/cancel and customer complaint operations.

### `AdminService`

Handles admin dashboard, room management, reservations, users, bills and complaint assignment.

### `StaffService`

Handles staff complaint listing and updates.

### `PdfService`

Generates booking receipt PDFs using OpenPDF.

## Repositories

- `UserRepository` - users, login state, profile, paginated users and password update.
- `RoomRepository` - room listing, search and save.
- `BookingRepository` - booking creation, update, cancellation, reservation pages and invoice details.
- `BillRepository` - bill listing and creation.
- `ComplaintRepository` - complaint create/update/assignment and timestamps.
- `CatalogRepository` - city and hotel catalog lookup.
- `PasswordResetRepository` - reset token hash create/find/invalidate/mark-used.

## DTOs

- `AuthDtos` - register, login, forgot password, reset password and auth response records.
- `BookingDtos` - booking create/update/response records.
- `ComplaintDtos` - complaint create/update/response records.
- `RoomDtos` - room search, response and save records.
- `UserDtos` - user summary, profile update and status update records.
- `BillDtos` - bill create/response records.
- `PageResponse<T>` - generic pagination wrapper.

## Utilities

### `ValidationUtils`

Provides backend validation for trimmed required fields, email, full name, phone, password, dates, guests and positive amounts.

### `HashUtils`

Provides SHA-256 hashing for passwords and reset tokens.

## Exception Handling

- `ApiException` represents validation/business errors.
- `ApiExceptionHandler` maps exceptions to consistent JSON error responses.
