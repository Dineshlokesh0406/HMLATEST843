# Frontend Reference

## Angular Structure

| Path | Purpose |
|---|---|
| `src/app/app.routes.ts` | Route declarations. |
| `src/app/core/models.ts` | Shared TypeScript interfaces and types. |
| `src/app/core/mock-hotel.service.ts` | API client and shared state service. |
| `src/app/core/validators.ts` | Reusable reactive form validators. |
| `src/app/pages/landing` | Public landing page and room cards. |
| `src/app/pages/login` | Login and forgot password. |
| `src/app/pages/register` | Customer registration. |
| `src/app/pages/customer-portal` | Customer booking, payment, complaints and profile. |
| `src/app/pages/admin-portal` | Admin management console. |
| `src/app/pages/staff-portal` | Staff complaint workspace. |

## Routes

| Route | Component | Purpose |
|---|---|---|
| `/` | `LandingComponent` | Public landing page. |
| `/register` | `RegisterComponent` | Customer registration. |
| `/login` | `LoginComponent` | Role login and forgot password. |
| `/customer` | `CustomerPortalComponent` | Customer portal. |
| `/admin` | `AdminPortalComponent` | Admin portal. |
| `/staff` | `StaffPortalComponent` | Staff portal. |
| `**` | `NotFoundComponent` | Fallback route. |

## Core Models

- `AppUser` - current/listed user account data.
- `Room` - room card/listing data.
- `Booking` - booking/reservation data.
- `Complaint` - complaint, assignment and resolution data.
- `Bill` - billing and payment total data.
- `RoomSearchCriteria` - customer room search form model.

## `MockHotelService`

Despite its name, this class acts as the Angular API client and state service.

Important responsibilities:

- Maintains session user in browser storage.
- Calls backend auth, customer, admin and staff APIs.
- Maps backend DTOs to frontend models.
- Loads role-specific dashboard data.
- Downloads receipt PDFs as blobs.

Important methods:

- `login(role, identifier, password)`
- `startPasswordReset(username, email, phoneNumber)`
- `resetPassword(token, newPassword, confirmPassword)`
- `getCustomerCities()`
- `getCustomerHotels(cityCode)`
- `downloadBookingReceipt(bookingId)`
- `loadAdminData()`
- `loadStaffData()`

## Validators

- `trimmedRequiredValidator()` - rejects whitespace-only values.
- `lettersAndSpacesValidator()` - allows alphabets and spaces.
- `emailFormatValidator()` - validates email format.
- `countryPhoneValidator()` - validates phone by selected country code.
- `passwordStrengthValidator()` - uppercase/lowercase/number/special rule.
- `cardNumberValidator()` - exactly 16 digits.
- `cvvValidator()` - exactly 3 digits.
- `futureOrTodayValidator()` - date is today or future.
- `afterDateValidator()` - date is after another control.
- `expiryDateValidator()` - valid future card expiry.
- `matchOtherControlValidator()` - matches confirm password.

## Components

### `LandingComponent`

Displays public hotel room cards and supports direct Book Now navigation into booking flow.

### `LoginComponent`

Handles role login, login confirmation popup, forgot password identity verification and reset password.

### `RegisterComponent`

Handles new customer registration using reactive forms and frontend validations.

### `CustomerPortalComponent`

Handles customer search, booking, payment timer, PDF download, My Bookings pagination, complaints and profile edit flow.

### `AdminPortalComponent`

Handles admin dashboard, room management, reservations, users, bills, complaints and admin profile.

### `StaffPortalComponent`

Handles assigned complaint listing, status updates, resolution notes and staff profile.

### `NotFoundComponent`

Fallback component for unknown routes.
